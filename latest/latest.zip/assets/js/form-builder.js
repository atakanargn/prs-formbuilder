class FedoraFormBuilder {
    #form_object = [];

    constructor(id, form_object) {
        const sortedData = Object.values(form_object).sort((a, b) => a.order - b.order);
        this.#form_object = sortedData;
        console.log(this.#form_object)
        this.#build_form(this.#form_object);
    }

    #get_element_templates() {

    }

    #build_form(form_object) {
        for (let i = 0; i < form_object.length; i++) {
            let element = form_object[i];
            console.log(element)
            this.#build_element(element);
        }
    }

    #build_element(element_object) {
        let new_element;
        switch (element_object.type) {
            case "boolean":
                new_element =
                    `
                    <div class="form-component" id="form-component-${element_object.cid}" style="width:${element_object.width} !important;">
                        <button id="helptext-button-${element_object.cid}" class="helptext-button" onclick="toggleHelp('${element_object.cid}')" style="display:none;float:left;">?</button>
                        <span id="component-required-${element_object.cid}" class="comp-required" style="margin-right:4px;">*</span>
                        <div id="comp-helptext-${element_object.cid}" class="popover-content">${element_object.helptext ? element_object.helptext : ""}</div>
                        <label class="toggle">
                                <input class="toggle-checkbox" type="checkbox" id="real-component-${element_object.cid}">
                                    <div class="toggle-switch"></div>
                                <span class="toggle-label form-edit-label" id="component-label-${element_object.cid}">${element_object.label}</span>
                        </label>
                    </div>
                `;
                break;
            case "textarea":
                new_element =
                    `
            <div class="form-component" id="form-component-${element_object.cid}" style="width:${element_object.width} !important;">
                <label id="component-label-${element_object.cid}" class="form-edit-label" style="float:left;margin-right:4px;">${element_object.label}</label>
                <button id="helptext-button-${element_object.cid}" class="helptext-button" onclick="toggleHelp('${element_object.cid}')" style="display:none;float:left;">?</button>
                <span id="component-required-${element_object.cid}" class="comp-required" style="margin-right:4px;">*</span>
                <div id="comp-helptext-${element_object.cid}" class="popover-content">${element_object.helptext ? element_object.helptext : ""}</div>
                <textarea id="real-component-${element_object.cid}"></textarea>
            </div>
            `;
                break;
            case "spacer":
                new_element =
                    `
            <div class="form-component" id="form-component-${element_object.cid}" style="width:${element_object.width} !important;">
                <hr id="real-component-${element_object.cid}" style="border:none;" />
            </div>
            `;
                break;
            case "text":
                new_element =
                    `
            <div class="form-component" id="form-component-${element_object.cid}" style="width:${element_object.width} !important;">
            <label id="component-label-${element_object.cid}" class="form-edit-label" style="float:left;margin-right:4px;">${element_object.label}</label>
            <button id="helptext-button-${element_object.cid}" class="helptext-button" onclick="toggleHelp('${element_object.cid}')" style="display:none;float:left;">?</button>
            <span id="component-required-${element_object.cid}" class="comp-required" style="margin-right:4px;">*</span>
            <div id="comp-helptext-${element_object.cid}" class="popover-content">${element_object.helptext ? element_object.helptext : ""}</div>
                <input type="text" id="real-component-${element_object.cid}" />
            </div>
            `;
                break;
            case "select":
                new_element =
                    `
            <div class="form-component" id="form-component-${element_object.cid}" style="width:${element_object.width} !important;">
                <label id="component-label-${element_object.cid}" class="form-edit-label" style="float:left;margin-right:4px;">${element_object.label}</label>
                <button id="helptext-button-${element_object.cid}" class="helptext-button" onclick="toggleHelp('${element_object.cid}')" style="display:none;float:left;">?</button>
                <span id="component-required-${element_object.cid}" class="comp-required" style="margin-right:4px;">*</span>
                <div id="comp-helptext-${element_object.cid}" class="popover-content">${element_object.helptext ? element_object.helptext : ""}</div>
                <select id="real-component-${element_object.cid}">
                    <option>Seçim 1</option>
                    <option>Seçim 2</option>
                    <option>Seçim 3</option>
                </select>
            </div>
            `;
                break;
        }
        document.getElementById("build").innerHTML = document.getElementById("build").innerHTML + new_element;
    }
}

var test_form = {
    "7910091708081799": {
        "cid": "7910091708081799",
        "order": 0,
        "type": "boolean",
        "width": "30%",
        "name": "",
        "label": "Boolean",
        "helptext": "Test",
        "required": false,
        "class": "",
        "css": "",
        "condition": 0,
        "placeholder": "",
        "validation": false,
        "default": false,
        "endpoint": false,
        "attr": "",
        "options": false
    },
    "4371271708081806": {
        "cid": "4371271708081806",
        "order": 1,
        "type": "spacer",
        "width": "70%",
        "name": "",
        "label": "",
        "helptext": false,
        "required": true,
        "class": "",
        "css": "",
        "condition": 0,
        "placeholder": "",
        "validation": false,
        "default": false,
        "endpoint": false,
        "attr": "",
        "options": false
    },
    "9996151708081812": {
        "cid": "9996151708081812",
        "order": 2,
        "type": "textarea",
        "width": "30%",
        "name": "",
        "label": "Bilgi",
        "helptext": false,
        "required": true,
        "class": "",
        "css": "",
        "condition": 0,
        "placeholder": "",
        "validation": false,
        "default": false,
        "endpoint": false,
        "attr": "",
        "options": false
    },
    "2765581708081823": {
        "cid": "2765581708081823",
        "order": 3,
        "type": "spacer",
        "width": "40%",
        "name": "",
        "label": "",
        "helptext": false,
        "required": true,
        "class": "",
        "css": "border:1pxdotted#333!important;width:50%;",
        "condition": 0,
        "placeholder": "",
        "validation": false,
        "default": false,
        "endpoint": false,
        "attr": "",
        "options": false
    },
    "2603771708081829": {
        "cid": "2603771708081829",
        "order": 4,
        "type": "select",
        "width": "30%",
        "name": "",
        "label": "Seçim",
        "helptext": "Yardım test",
        "required": true,
        "class": "",
        "css": "",
        "condition": 0,
        "placeholder": "",
        "validation": false,
        "default": false,
        "endpoint": false,
        "attr": "",
        "options": false
    }
};

var ffb = new FedoraFormBuilder("build", test_form);